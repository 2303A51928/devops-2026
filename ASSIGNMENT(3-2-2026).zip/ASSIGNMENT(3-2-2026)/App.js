import React from "react";
import Cart from "./cart";  // Import Cart component

function App() {
  return (
    <div>
      <Cart />  {/* Use Cart component */}
    </div>
  );
}

export default App;