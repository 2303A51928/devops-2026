import React, { useState } from "react";

const books = [
  { id: 1, title: "Atomic Habits", price: 499, color: "#FDE2E4" },
  { id: 2, title: "Rich Dad Poor Dad", price: 399, color: "#E2ECE9" },
  { id: 3, title: "Think Like a Monk", price: 450, color: "#FFF1C1" },
  { id: 4, title: "The Alchemist", price: 350, color: "#E4C1F9" },
  { id: 5, title: "Deep Work", price: 520, color: "#CDB4DB" },
  { id: 6, title: "Ikigai", price: 299, color: "#BDE0FE" },
];

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (book) => {
    setCart([...cart, book]);
  };

  const totalPrice = cart.reduce((sum, book) => sum + book.price, 0);

  return (
    <div
      style={{
        fontFamily: "Segoe UI",
        padding: "30px",
        backgroundColor: "#F8F9FA",
        minHeight: "100vh",
      }}
    >
      <h1 style={{ textAlign: "center", color: "#343A40" }}>📚 BookNest</h1>
      <p style={{ textAlign: "center", color: "#6C757D" }}>
        Your favorite books, one click away
      </p>

      {/* Books Section */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "20px",
          marginTop: "30px",
        }}
      >
        {books.map((book) => (
          <div
            key={book.id}
            style={{
              backgroundColor: book.color,
              padding: "20px",
              borderRadius: "15px",
              boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
              textAlign: "center",
            }}
          >
            <h3 style={{ color: "#212529" }}>{book.title}</h3>
            <p style={{ fontWeight: "bold" }}>₹{book.price}</p>
            <button
              onClick={() => addToCart(book)}
              style={{
                backgroundColor: "#212529",
                color: "white",
                border: "none",
                padding: "8px 14px",
                borderRadius: "20px",
                cursor: "pointer",
              }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>

      {/* Cart Section */}
      <div
        style={{
          marginTop: "40px",
          padding: "20px",
          backgroundColor: "#FFFFFF",
          borderRadius: "15px",
          boxShadow: "0 6px 12px rgba(0,0,0,0.1)",
        }}
      >
        <h2>🛒 Shopping Cart</h2>

        {cart.length === 0 ? (
          <p style={{ color: "#6C757D" }}>Your cart is empty</p>
        ) : (
          <ul>
            {cart.map((item, index) => (
              <li key={index}>
                {item.title} — ₹{item.price}
              </li>
            ))}
          </ul>
        )}

        <h3>Total: ₹{totalPrice}</h3>
      </div>
    </div>
  );
}

export default App;
